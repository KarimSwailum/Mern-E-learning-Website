import React, { useState } from "react";
import axios from "axios";
import "./CreateCourseModal.css";
import CloseIcon from "@mui/icons-material/Close";
import { useEffect } from "react";

const RefundCourse = (props) => {
  const params = new URLSearchParams(window.location.search);
  const courseId = params.get("courseId");
  const [traineeId, setTraineeId] = useState("");
  let tid;

  const close = () => {
    props.onClick(false);
  };
  useEffect(() => {
    axios.get("/getToken", { withCredentials: true }).then((res) => {
      setTraineeId(res.data._id);
      tid = res.data._id;
      console.log(traineeId);
    });
  }, []);

  const postData = async () => {
    await axios
      .get(
        `http://localhost:8000/refundReq?id=${traineeId}&courseID=${courseId}`,
        {
          withCredentials: true,
        }
      )
      .then(() => {
        props.onClick(false);
        props.variant("Refund Requested Successfully", "success");
      });
  };

  return (
    <div className="cont">
      <div className="create-course-container">
        <div className="create-course-profileRequest">
          <div className="create-course-group23">
            <div className="closeIcon" onClick={close}>
              <CloseIcon />
            </div>
            <span className="create-course-textRequest Title_PoppinsLarge">
              <span>Do you want to request a refund?</span>
            </span>
          </div>
          <div className="submitCourseRequest" onClick={postData}>
            <span className="submitCourseTextYes">Yes</span>
          </div>
          <div className="submitCourseRequest1" onClick={close}>
            <span className="submitCourseTextNo">No</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RefundCourse;
