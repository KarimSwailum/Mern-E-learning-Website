import React, { useState } from "react";
import axios from "axios";
import PropTypes from "prop-types";
import "./CreateCourseModal.css";
import { Button, TextField } from "@mui/material";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Input from "@mui/material/Input";
import FilledInput from "@mui/material/FilledInput";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import CloseIcon from "@mui/icons-material/Close";
import { useEffect } from "react";

const RequestAccessModal = (props) => {
  const params = new URLSearchParams(window.location.search);
  const courseId = params.get("courseId");
  const [traineeId, setTraineeId] = useState("");

  const close = () => {
    props.onClick(false);
  };
  useEffect(() => {
    setTraineeId("63af0c50fd4c0d941a2fedde");
    axios.get("http://localhost:8000/getToken").then((res) => {});
  }, []);

  const postData = async () => {
    await axios
      .post(
        `http://localhost:8000/traineeSendRequest?id=${traineeId}&course=${courseId}`
      )
      .then((res) => {
        console.log(res.data);
        props.variant("Course Request Sent Successfully", "success");
      });
  };

  return (
    <div className="cont">
      <div className="create-course-container">
        <div className="create-course-profileRequest">
          <div className="create-course-group23">
            <div className="closeIcon" onClick={close}>
              <CloseIcon />
            </div>
            <span className="create-course-textRequest Title_PoppinsLarge">
              <span>Do you want to request access to this course?</span>
            </span>
          </div>
          <div className="submitCourseRequest" onClick={postData}>
            <span className="submitCourseTextYes">Yes</span>
          </div>
          <div className="submitCourseRequest1" onClick={close}>
            <span className="submitCourseTextNo">No</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestAccessModal;
