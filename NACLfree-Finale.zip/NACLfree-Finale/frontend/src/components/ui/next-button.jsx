import React from "react";

import "./next-button.css";

const NextButton = (props) => {
  return <div className="next-button-container"></div>;
};

export default NextButton;
