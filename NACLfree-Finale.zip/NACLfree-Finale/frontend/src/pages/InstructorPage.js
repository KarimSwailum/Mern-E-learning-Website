import InstructorView from '../components/forms/InstructorView';

function InstructorPage()
{
   return ( 
    <section>
        <h1>course actions</h1>
        <InstructorView />
    </section>

   );
}

export default InstructorPage;